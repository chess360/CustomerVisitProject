package net.javaguides.springboot.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.javaguides.springboot.TableNameandItem.TimeEntity;

@Repository
public interface TimeRepo extends JpaRepository<TimeEntity, Integer>{

}
