package net.javaguides.springboot.TableNameandItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="StandardRecomendationTable")
public class StandardRecomendation {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="Standard_Recomendation")
	private String Stdrec;
	
	public StandardRecomendation() {
		
	}

	public StandardRecomendation(String stdrec) {
		super();
		Stdrec = stdrec;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStdrec() {
		return Stdrec;
	}

	public void setStdrec(String stdrec) {
		Stdrec = stdrec;
	}
	
	
}
