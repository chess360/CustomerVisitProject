package net.javaguides.springboot.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.RegistrationRepo;
import net.javaguides.springboot.TableNameandItem.RegistrationEntity;

@CrossOrigin(origins="http://localhost:4200" , maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class RegistrationRestController {

	@Autowired
	private RegistrationRepo registrationrepo;
	
	@GetMapping("getUser")
	public List<RegistrationEntity> alluser(){
		return registrationrepo.findAll();
		
	}
	
	@PostMapping("addUser")
	public RegistrationEntity adduser(@RequestBody RegistrationEntity newuser) {
		return registrationrepo.save(newuser);
	}
}
