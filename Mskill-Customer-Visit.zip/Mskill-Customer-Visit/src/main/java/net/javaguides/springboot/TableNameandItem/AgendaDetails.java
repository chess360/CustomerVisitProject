package net.javaguides.springboot.TableNameandItem;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="agenda_details")
public class AgendaDetails {
    
	@Id
	@Column(name="agenda_id")
	private int agenda_id;
	
	@Column(name="startTime")
	private Time time;
	
	@Column(name="endtime")
	private Time time1;
	
	@Column(name="activity")
	private String activity;
	
	@Column(name="spoc")
	private String spoc;
	
	@Column(name="remarks")
	private String remarks;
	
	@Column(name="status")
	private String status;
	
	
    public AgendaDetails() {}


	public AgendaDetails(int agenda_id, Time time, Time time1, String activity, String spoc, String remarks,
			String status) {
		super();
		this.agenda_id = agenda_id;
		this.time = time;
		this.time1 = time1;
		this.activity = activity;
		this.spoc = spoc;
		this.remarks = remarks;
		this.status = status;
	}


	public int getAgenda_id() {
		return agenda_id;
	}


	public void setAgenda_id(int agenda_id) {
		this.agenda_id = agenda_id;
	}


	public Time getTime() {
		return time;
	}


	public void setTime(Time time) {
		this.time = time;
	}


	public Time getTime1() {
		return time1;
	}


	public void setTime1(Time time1) {
		this.time1 = time1;
	}


	public String getActivity() {
		return activity;
	}


	public void setActivity(String activity) {
		this.activity = activity;
	}


	public String getSpoc() {
		return spoc;
	}


	public void setSpoc(String spoc) {
		this.spoc = spoc;
	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
    
    public String toString() {
    	return "AgendaDetails [agenda_id=" + agenda_id + ", time=" +time+ ",time1=" +time1+ ", activity=" + activity+ ",remarks=" + remarks +" ,status="+status+ ", spoc=" + spoc + "]";
    			
    }
	
}
