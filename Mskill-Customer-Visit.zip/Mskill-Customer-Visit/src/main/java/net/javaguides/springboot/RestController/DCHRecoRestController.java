package net.javaguides.springboot.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.DCHRecoRepo;
import net.javaguides.springboot.ResourceNotFoundException.ResourceNotFoundException;
import net.javaguides.springboot.TableNameandItem.DCHRecomendation;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class DCHRecoRestController {
	
	@Autowired
	private DCHRecoRepo DCHRecorepo;
	
	@GetMapping("getDchRec")
	public List<DCHRecomendation> allReco(){
		return DCHRecorepo.findAll();
				
	}
	
	@PostMapping("addDchRec")
	public DCHRecomendation addDchRec(@RequestBody DCHRecomendation newReco) {
		return DCHRecorepo.save(newReco);
	}
	
	@DeleteMapping("deleteDchReco/{id}")
	public ResponseEntity<Map<String, Boolean>>deleteDchReco(@PathVariable Integer id){
		DCHRecomendation table= DCHRecorepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("customer not found in id: " +id));
		DCHRecorepo.delete(table);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("getDchRecoById/{id}")
	public ResponseEntity<DCHRecomendation> getById(@PathVariable Integer id){
		DCHRecomendation table = DCHRecorepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("Details Not Found:"+id));
		
		return ResponseEntity.ok(table);
		
	}
	
	
	@PutMapping("editDchReco/{id}")
	public ResponseEntity<DCHRecomendation> updateInterest(@PathVariable Integer id,@RequestBody DCHRecomendation Dchrec){
		DCHRecomendation table = DCHRecorepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("Details Not Found:"+id));
		
		table.setDchrec(Dchrec.getDchrec());
		
		DCHRecomendation updateDchrec=DCHRecorepo.save(table);
		return ResponseEntity.ok(updateDchrec);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
