package net.javaguides.springboot.TableNameandItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer_Details")
public class CustomerDetailsTable {
    
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@Column(name="Customer")
	private String customer;
	
	@Column(name="Project")
	private String project;
	
	@Column(name="Location")
	private String location;
	
	public void CustomerListTable() {
		
	}

	public CustomerDetailsTable( String customer, String project, String location) {
		super();
		this.customer = customer;
		this.project = project;
		this.location = location;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
	
	
}
