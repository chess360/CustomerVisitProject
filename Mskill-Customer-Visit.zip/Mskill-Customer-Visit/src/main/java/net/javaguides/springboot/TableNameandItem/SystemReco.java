package net.javaguides.springboot.TableNameandItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="System_Recomendation")
public class SystemReco {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="System_Recomendation")
	private String sysRec;
	
	public SystemReco() {
		
	}

	public SystemReco(String sysRec) {
		super();
		this.sysRec = sysRec;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSysRec() {
		return sysRec;
	}

	public void setSysRec(String sysRec) {
		this.sysRec = sysRec;
	}
	
	
}
