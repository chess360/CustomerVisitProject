package net.javaguides.springboot.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AgendaRepo extends CrudRepository<net.javaguides.springboot.TableNameandItem.AgendaDetails,Integer> {

}
