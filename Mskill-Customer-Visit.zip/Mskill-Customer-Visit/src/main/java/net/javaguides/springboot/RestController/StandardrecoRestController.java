package net.javaguides.springboot.RestController;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.StandardRecoRepo;
import net.javaguides.springboot.TableNameandItem.StandardRecomendation;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class StandardrecoRestController {

	private StandardRecoRepo standardrecorepo;
	
	@GetMapping("getStdRec")
	public List<StandardRecomendation> allStdRec(){
		return standardrecorepo.findAll();
	}
	
	@PostMapping("addStdRec")
	public StandardRecomendation addStdRec(@RequestBody StandardRecomendation newstdrec) {
		return standardrecorepo.save(newstdrec);
	}
}
