package net.javaguides.springboot.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.CustomerDetailsRepo;
import net.javaguides.springboot.TableNameandItem.CustomerDetailsTable;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials = "false")
@RestController
@RequestMapping("/api/")
public class CustomerDetailsRestController {
	
	@Autowired
	private CustomerDetailsRepo customerdetails;
	
	@GetMapping("getcustomerdetails")
	public List<CustomerDetailsTable> getList() {
		return customerdetails.findAll();
	}
	
	@PostMapping("adddetailscustomer")
	public CustomerDetailsTable addcustomer(@RequestBody CustomerDetailsTable newcustomer) {
		return customerdetails.save(newcustomer);
	}
}
