package net.javaguides.springboot.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.DateRepo;
import net.javaguides.springboot.TableNameandItem.DateEntity;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class DateRestController {

	@Autowired
	private DateRepo daterepo;
	
	@GetMapping("getDate")
	public List<DateEntity> getDate(){
		return daterepo.findAll();
	}
	
	
	@PostMapping("saveDate")
	public DateEntity saveDate(@RequestBody DateEntity newdate) {
		return daterepo.save(newdate);
	}
	
	
}
