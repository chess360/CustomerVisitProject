package net.javaguides.springboot.TableNameandItem;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DCH_Recomendation_Table")
public class DCHRecomendation {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="DCH_Recomendation")
	private String dchrec;
	
	public DCHRecomendation() {
		
	}

	public DCHRecomendation(String dchrec) {
		super();
		this.dchrec = dchrec;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDchrec() {
		return dchrec;
	}

	public void setDchrec(String dchrec) {
		this.dchrec = dchrec;
	}
	
	
	
}
