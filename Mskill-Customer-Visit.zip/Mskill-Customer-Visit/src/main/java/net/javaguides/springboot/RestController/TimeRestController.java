package net.javaguides.springboot.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.TimeRepo;
import net.javaguides.springboot.TableNameandItem.TimeEntity;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class TimeRestController {
	
	@Autowired
	private TimeRepo timerepo;
	
	@GetMapping("getTime")
	public List<TimeEntity> getTime(){
		return timerepo.findAll();
	}
	
	@PostMapping("saveTime")
	public TimeEntity saveTime(@RequestBody TimeEntity newtime) {
		return timerepo.save(newtime);
	}
}
