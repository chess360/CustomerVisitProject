package net.javaguides.springboot.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.AgendaRepo;
import net.javaguides.springboot.ResourceNotFoundException.ResourceNotFoundException;
import net.javaguides.springboot.TableNameandItem.AgendaDetails;


@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class CustomerVisitAgendaController {

	@Autowired
	private AgendaRepo agendarepo;
	
	
    @GetMapping("getAgenda")
	public List<AgendaDetails> getAgenda(){
    	return(List<AgendaDetails>) agendarepo.findAll();    
    	
    }
	
    @PostMapping("saveAgenda")
    public AgendaDetails saveAgenda(@RequestBody AgendaDetails agenda) {
    	return agendarepo.save(agenda);
    }
    
    @DeleteMapping(value="/deleteAgenda/{id}")
    public ResponseEntity<Map<String,Boolean>>deleteinterest(@PathVariable int id){
    	AgendaDetails agenda= agendarepo.findById(id).orElseThrow(()->new ResourceNotFoundException("customer interest wiith id not found:"+id));
    	agendarepo.delete(agenda);
    	Map<String,Boolean> response = new HashMap<>();
    	response.put("Deleted",Boolean.TRUE);
    	return ResponseEntity.ok(response);
    }
    
    @GetMapping("getAgendaById/{id}")
    public ResponseEntity<AgendaDetails> updateInterest(@PathVariable Integer id, @RequestBody AgendaDetails agenda){
    	AgendaDetails table=agendarepo.findById(id).orElseThrow(()->new ResourceNotFoundException("Details Not Found:"+id));
    	
    	table.setAgenda_id(agenda.getAgenda_id());
    	table.setTime(agenda.getTime());
    	table.setTime1(agenda.getTime1());
    	table.setActivity(agenda.getActivity());
    	table.setRemarks(agenda.getRemarks());
    	table.setSpoc(agenda.getSpoc());
    	
    	AgendaDetails updateagenda=agendarepo.save(table);
    	return ResponseEntity.ok(updateagenda);
    }
    
    
    
    
    
    
    
    
}
