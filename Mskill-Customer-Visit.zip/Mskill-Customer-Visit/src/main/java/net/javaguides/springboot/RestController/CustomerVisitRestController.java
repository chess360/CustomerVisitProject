package net.javaguides.springboot.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.Repository.CustomerVisitRepo;
import net.javaguides.springboot.ResourceNotFoundException.ResourceNotFoundException;
import net.javaguides.springboot.TableNameandItem.TableNameAndEntity;

@CrossOrigin(origins= {"*"}, maxAge=4800, allowCredentials="false")
@RestController
@RequestMapping("/api/")
public class CustomerVisitRestController {

	@Autowired
	private CustomerVisitRepo customervisitrepo;
	
	@GetMapping("getData")
	public List<TableNameAndEntity> getAllExpectations(){
		return customervisitrepo.findAll();
	}
	
	@PostMapping("addCustomer")
	public TableNameAndEntity addCustomer(@RequestBody TableNameAndEntity newCus) {
		return customervisitrepo.save(newCus);
	}
	
	
	@DeleteMapping(value="/deleteCus/{id}")
	public ResponseEntity<Map<String, Boolean>>deleteCustomer(@PathVariable int id){
		TableNameAndEntity customer=customervisitrepo.findById(id).orElseThrow(()->new ResourceNotFoundException("customer not found in id:"+ id));
		customervisitrepo.delete(customer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@GetMapping("getCusById/{id}")
	public ResponseEntity<TableNameAndEntity> getById(@PathVariable int id){
		TableNameAndEntity customer = customervisitrepo.findById(id).orElseThrow(()->new ResourceNotFoundException("customer not found in id: "+id));
		return ResponseEntity.ok(customer);
		
	}
	
	
	@PutMapping("editCus/{id}")
	public ResponseEntity<TableNameAndEntity> updateCustomer(@PathVariable int id,@RequestBody TableNameAndEntity customerDetails){
		TableNameAndEntity customer=customervisitrepo.findById(id).orElseThrow(()-> new ResourceNotFoundException("customer not found in id:"+id));
		customer.setInterest(customerDetails.getInterest());
		customer.setRemark(customerDetails.getRemark());
		
		TableNameAndEntity updatedCustomer= customervisitrepo.save(customer);
		return ResponseEntity.ok(updatedCustomer);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
